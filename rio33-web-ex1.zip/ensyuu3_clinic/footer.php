<?php wp_footer(); ?>  <!-- </body>の直前に入れる -->
</body>

<!-- footer -->
<footer class="footer">
  <div class="footer__inner inner">
    <div class="footer__wrapper">
      <div class="footer__left pc-only u-desktop">
        <h2 class="footer__logo">
          <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
            <img class="footer__logo-img" src="<?php echo get_template_directory_uri(); ?>/img/common/footer_logo.png" alt="フッターロゴ"></a>
        </h2>
      </div>
      <div class="footer__right">
    <!-- footer-nav -->
      <nav class="footer-nav">
        <ul class="footer-nav__items">
          <li class="footer-nav__item">
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>">ホーム</a>
          </li>
          <li class="footer-nav__item">
            <a href="<?php echo home_url("about"); ?>">クリニックについて</a>
          </li>
          <li class="footer-nav__item">
            <a href="<?php echo home_url("news"); ?>">お知らせ</a>
          </li>
          <li class="footer-nav__item">
            <a href="<?php echo home_url("treatment"); ?>">診療案内</a>
          </li>
          <li class="footer-nav__item">
            <a href="<?php echo home_url("contact"); ?>">お問い合わせ</a>
          </li>
        </ul>
      </nav>
    <!-- footer-line -->
      <div class="footer__line line"></div>
    <!-- footer-logo -->
      <h2 class="footer__logo sp-only u-mobile">
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
          <img class="footer__logo-img" src="<?php echo get_template_directory_uri(); ?>/img/common/footer_logo.png" alt="フッターロゴ">
        </a>
      </h2>
    <!-- footer-contact -->
      <p class="footer__address">福岡県福岡市中央区渡邉123</p>
      <p class="footer__tel">Tel. 093-0000-0000</p>
      </div>  <!-- pc-right -->
    </div> <!-- wrapper -->
  </div> <!-- inner -->
<!-- footer-copyright -->
  <div class="footer__copyright">
    <small>&copy;2022 Watanabe neuro-spone clinic</small>
  </div>
</footer>




