<?php

function add_css_js() {
	//CSSの読み込み
	wp_enqueue_style('swiper-css', get_theme_file_uri('/css/swiper-bundle.min.css'));
	wp_enqueue_style('style', get_theme_file_uri().'/css/style.css',
	[],
	date("YmdHis"),);

	//JavaScript
	//デフォルトの jQuery は読み込まない
	wp_deregister_script('jquery');
	wp_enqueue_script('jquery','https://code.jquery.com/jquery-3.6.0.min.js', array(), '', true);
	wp_enqueue_script('swiper-min-js', get_theme_file_uri('/js/swiper-bundle.min.js'), array(), '', true);
	wp_enqueue_script('swiper-js', get_theme_file_uri('/js/swiper.js'), array(), '', true);
	wp_enqueue_script('js', get_theme_file_uri('/js/script.js'), array(), '', true);
}
//関数名add_scripts()を表側で呼び出す
add_action('wp_enqueue_scripts', 'add_css_js');
// head meta ここまでーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーー


// アイキャッチ設定表示
function custom_setup(){
    add_theme_support('post-thumbnails');
    add_theme_support('menus');
}
add_action('after_setup_theme','custom_setup');
// アイキャッチ設定表示　ここまで

// アーカイブページ作成（archive.php）
function post_has_archive( $args, $post_type ) {
	if ( 'post' == $post_type ) {
		$args['rewrite'] = true;
		$args['has_archive'] = 'news'; // 任意のURL（一覧ページ）
	}
	return $args;
}
add_filter( 'register_post_type_args', 'post_has_archive', 10, 2 );
// アーカイブページ作成（archive.php）ここまで


// news sidebar 月別
function my_archives_link($link_html){
	$link_html = preg_replace('@<li>@i', '<li class="archive-nav__item">', $link_html);
	return $link_html;
	}
	add_filter('get_archives_link', 'my_archives_link');
// news sidebar 月別　ここまで





// 消さない
?>

