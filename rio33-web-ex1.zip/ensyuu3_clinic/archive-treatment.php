<?php get_header(); ?>

<!-- mv -->
<main>
  <div class="mv2 treatment__mv">
    <div class="mv2__title-wrapper">
      <h2 class="mv2__title">Treatment</h2>
      <p class="mv2__subtitle">診療科目</p>
    </div>
  </div> <!-- mv -->
</main>  

<!-- page-nav -->
<p class="page-nav">
  <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="page-nav__accent">HOME</a>
  <span class="page-nav__arrow">＞</span>
  診療科目
</p>

<div class="treatment__btn-wrapper">
  <a href="#link1" class="blue-btn treatment__btn">身体の痛み</a>
  <a href="#link2" class="blue-btn treatment__btn">身体機能の不調</a>
  <a href="#link3" class="blue-btn treatment__btn">健診</a>
</div>

<section class="category1__wrapper">
  <div class="treatment__inner">
  <!-- title -->
    <h2 class="category1-title section-title" id="link1">
      <div class="section-title__img">
        <img src="<?php echo get_template_directory_uri(); ?>/img/common/title_icon.png" alt="">
      </div>
      <p class="section-title__ja">
        身体の痛み
      </p>
    </h2>
    <p class="section-text">
      ちょっとした痛みからやってくる病気も少なからず存在します。<br>少しでも異変を感じたら早期に受診しましょう。
    </p>
    <div class="eyecatch-wrapper">
      <?php
      // 1. 記事を取得するための条件指定
        $args = array(
          'post_type' => 'treatment',
          'posts_per_page' => 3,
          'order' => 'ASC',
          'tax_query' => array(
            array(
              'taxonomy' => 'treatment-category',
              'terms' => array('category1'),
              'field' => 'slug'
            ),
          ),
        );
      // 2. クエリの定義「WP_Query」
        $the_query = new WP_Query( $args );
      ?>
      <!-- 3. 取得内容をループさせ、取得内容を表示 -->
      <?php if ( $the_query->have_posts() ): while ( $the_query->have_posts() ): $the_query->the_post(); ?>
      <!-- ループさせる内容ここから -->
        <a href="<?php the_permalink(); ?>" class="eyecatch-content">
          <div class="eyecatch-content__img">
            <?php the_post_thumbnail('thumbnail'); ?>
          </div>
          <p class="eyecatch-content__name">
            <?php the_title(); ?>
          </p>
        </a>
      <!-- ループさせる内容ここまで -->
      <!-- 4. ループの終了と投稿データのリセット「wp_reset_postdata」 -->
      <?php endwhile; endif; wp_reset_postdata(); ?>
    </div>
  </div> <!-- inner -->
</section>
<section class="category2__wrapper">
  <div class="treatment__inner">
  <!-- title -->
    <h2 class="category2-title section-title" id="link2">
      <div class="section-title__img">
        <img src="<?php echo get_template_directory_uri(); ?>/img/common/title_icon.png" alt="">
      </div>
      <p class="section-title__ja">
      身体機能の不調
      </p>
    </h2>
    <p class="section-text">
      歩行障害や呂律が回らないなど、脳の病気を疑う要注意症状です。<br>
      一刻も早く頭部CT/MRIなどの精査を行い、速やかに原因を特定、治療を開始する必要があります。
    </p>
    <div class="eyecatch-wrapper">
      <?php
      // 1. 記事を取得するための条件指定
        $args = array(
          'post_type' => 'treatment',
          'posts_per_page' => 3,
          'order' => 'ASC',
          'tax_query' => array(
            array(
              'taxonomy' => 'treatment-category',
              'terms' => array('category2'),
              'field' => 'slug'
            ),
          ),
        );
      // 2. クエリの定義「WP_Query」
        $the_query = new WP_Query( $args );
      ?>
      <!-- 3. 取得内容をループさせ、取得内容を表示 -->
      <?php if ( $the_query->have_posts() ): while ( $the_query->have_posts() ): $the_query->the_post(); ?>
      <!-- ループさせる内容ここから -->
        <a href="<?php the_permalink(); ?>" class="eyecatch-content">
          <div class="eyecatch-content__img">
            <?php the_post_thumbnail('thumbnail'); ?>
          </div>
          <p class="eyecatch-content__name">
            <?php the_title(); ?>
          </p>
        </a>
      <!-- ループさせる内容ここまで -->
      <!-- 4. ループの終了と投稿データのリセット「wp_reset_postdata」 -->
      <?php endwhile; endif; wp_reset_postdata(); ?>
    </div>
  </div> <!-- inner -->
</section>
<section class="category3__wrapper">
  <div class="treatment__inner">
  <!-- title -->
    <h2 class="category3-title section-title" id="link3">
      <div class="section-title__img">
        <img src="<?php echo get_template_directory_uri(); ?>/img/common/title_icon.png" alt="">
      </div>
      <p class="section-title__ja">
        健診
      </p>
    </h2>
    <p class="section-text">
    脳卒中は予防が第一です。早期発見・早期治療で人生まだまだ楽しみたい！<br>
    脳の状態を知ることのできる大変貴重な機会です。一度受診してみませんか？
    </p>
    <div class="eyecatch-wrapper">
      <?php
      // 1. 記事を取得するための条件指定
        $args = array(
          'post_type' => 'treatment',
          'posts_per_page' => 3,
          'order' => 'ASC',
          'tax_query' => array(
            array(
              'taxonomy' => 'treatment-category',
              'terms' => array('category3'),
              'field' => 'slug'
            ),
          ),
        );
      // 2. クエリの定義「WP_Query」
        $the_query = new WP_Query( $args );
      ?>
      <!-- 3. 取得内容をループさせ、取得内容を表示 -->
      <?php if ( $the_query->have_posts() ): while ( $the_query->have_posts() ): $the_query->the_post(); ?>
      <!-- ループさせる内容ここから -->
        <a href="<?php the_permalink(); ?>" class="eyecatch-content">
          <div class="eyecatch-content__img">
            <?php the_post_thumbnail('thumbnail'); ?>
          </div>
          <p class="eyecatch-content__name">
            <?php the_title(); ?>
          </p>
        </a>
      <!-- ループさせる内容ここまで -->
      <!-- 4. ループの終了と投稿データのリセット「wp_reset_postdata」 -->
      <?php endwhile; endif; wp_reset_postdata(); ?>
    </div>
  </div> <!-- inner -->
</section>

<?php get_footer(); ?>



