<?php get_header(); ?>

<!-- mv -->
<main>
  <div class="top-mv">
    <div class="top-mv__wrapper">
      <div class="top-mv__wrapper-flex">
        <!-- Swiper START -->
        <div class="top-mv__img swiper">
          <!-- メイン表示部分 -->
          <div class="swiper-wrapper">
            <!-- 各スライド -->
            <div class="swiper-slide">
              <picture>
                <source class="top-mv__img--pc" srcset="<?php echo get_template_directory_uri(); ?>/img/top/top_mv_1.jpg" media="(min-width:768px)" />
                <img class="top-mv__img--sp" src="<?php echo get_template_directory_uri(); ?>/img/top/top_mv_1_sp.jpg" alt="">
              </picture>
            </div>
            <div class="swiper-slide">
              <picture>
                <source class="top-mv__img--pc" srcset="<?php echo get_template_directory_uri(); ?>/img/top/top_mv_2.jpg" media="(min-width:768px)" />
                <img class="top-mv__img--sp" src="<?php echo get_template_directory_uri(); ?>/img/top/top_mv_2_sp.jpg" alt="">
              </picture>
            </div>
            <div class="swiper-slide">
              <picture>
                <source class="top-mv__img--pc" srcset="<?php echo get_template_directory_uri(); ?>/img/top/top_mv_3.jpg" media="(min-width:768px)" />
                <img class="top-mv__img--sp" src="<?php echo get_template_directory_uri(); ?>/img/top/top_mv_3_sp.jpg" alt="">
              </picture>
            </div>
          </div>
        </div>
        <!-- Swiper END -->
        <div class="top-mv__btm">
          <span></span>
        </div>
      </div> <!-- mv__wrapper-flex -->
      <div class="top-mv__text">
        <img src="<?php echo get_template_directory_uri(); ?>/img/top/mv_text_pc.svg" alt="">
      </div>
    </div> <!-- top-mv__wrapper -->
  </div> <!-- top-mv -->
  
<!-- news -->
<section class="top-news">
  <div class="top-news__circle"></div>
  <div class="top-news__inner">
    <h2 class="top-news-title section-title">
      <div class="section-title__img">
        <img src="<?php echo get_template_directory_uri(); ?>/img/common/title_icon.png" alt="">
      </div>
      <p class="section-title__ja">お知らせ</p>
      <p class="section-title__en">News</p>
    </h2>

    <div class="top-news__items">
      <?php
        $args = array(
          'post_type' => 'post',
          // 投稿タイプ
          // ・投稿        ：post  
          // ・固定ページ  ：page 
          // ・カスタム投稿：カスタム投稿タイプ名
          'posts_per_page' => 3,
        );
        $the_query = new WP_Query( $args );
      ?>
      <?php if( $the_query->have_posts()): ?>
      <?php while( $the_query->have_posts()):  $the_query->the_post(); ?>
        <!-- ループする投稿記事 -->
        <a href="<?php the_permalink(); ?>" class="top-news__item top-news-item">
          <div class="top-news-item__text-wrapper">
            <div class="top-news-item__meta">
              <time class="date top-news-item__meta-date" datetime="2022-03-31">
                <?php echo get_the_date(); ?>
              </time>
              <div class="category-wrapper">
                                          
              <?php if (has_term('','category')): ?>
                <div class="category-border">
                  <?php
                    $cats = get_the_terms($post->ID,'category');
                    foreach ( $cats as $cat ){
                      echo $cat->cat_name;
                      $cat_id = $cat->term_id;
                      $cat_color = 'category_'.$cat_id;
                      $text_color = get_field('color-pic',$cat_color);
                  ?>
                    <span class="category-text" 
                      style="color: <?php echo $text_color; ?>" 
                      style="border: 1px solid <?php echo $text_color; ?>">
                      <?php $cat = get_the_category(); $cat = $cat[0]; { echo $cat->cat_name; } ?>
                    </span>
                  <?php } ?>
                </div>
              <?php endif; ?>
              
              </div>
            </div> <!-- meta -->
            <p class="top-news-item__title">
              <?php the_title(); ?>
            </p>
          </div> <!-- text-wrapper -->
          <div class="top-news__arrow-wrapper--newsitem arrow-wrapper--newsitem pc-only u-desktop">
            <div class="arrow"></div> 
            <div class="arrow-rotate"></div>
          </div>
        </a>
        <div class="top-news__line line"></div>
      <?php endwhile; ?>
      <?php else: ?>
      <?php endif; ?>
    </div> <!-- items -->

    <a href="<?php echo home_url("news"); ?>" class="top-news__btn btn">
      <p class="btn__text">もっと見る</p>
      <div class="top-news__arrow-wrapper--btn arrow-wrapper--btn">
        <div class="arrow"></div>
        <div class="arrow-rotate"></div>
      </div>
    </a>
  </div> <!-- inner -->
</section>

<!-- about -->
<section class="top-about">
  <div class="top-about__circle"></div>
  <div class="top-about__flex inner">
    <div class="top-about__img">
      <img src="<?php echo get_template_directory_uri(); ?>/img/top/top_about.png" alt="">
    </div>
    <div class="top-about__wrapper section-index-text-wrapper">
      <h2 class="top-about-title section-title">
        <div class="section-title__img">
          <img src="<?php echo get_template_directory_uri(); ?>/img/common/title_icon.png" alt="">
        </div>
        <p class="section-title__ja">クリニックのご紹介</p>
        <p class="section-title__en">About</p>
      </h2>
      <!-- <h3 class="top-about__text-h3">安心して相談できるかかりつけ医</h3>
      <p class="top-about__text">
        地域の皆様の第一の相談相手になりたい<br>頭のことなら”渡邉脳神経外科クリニック”<br>そんなニーズにお応えできるクリニックを目指しています。
      </p> -->
      <?php the_field('top_about', 8); ?>
      <a href="<?php echo home_url("about"); ?>" class="top-about__btn btn">
        <p class="btn__text">クリニックのご紹介</p>
        <div class="top-about__arrow-wrapper--btn arrow-wrapper--btn">
          <div class="arrow"></div>
          <div class="arrow-rotate"></div>
        </div>
      </a>
    </div> <!-- wrapper -->
  </div> <!-- inner -->
</section>

<!-- treatment -->
<section class="top-treatment">
  <div class="top-treatment__circle"></div>
  <div class="top-treatment__flex inner">
    <div class="top-treatment__img">
      <img src="<?php echo get_template_directory_uri(); ?>/img/top/top_treatment.png" alt="">
    </div>
    <div class="top-treatment__wrapper section-index-text-wrapper">
      <h2 class="top-treatment-title section-title">
        <div class="section-title__img">
          <img src="<?php echo get_template_directory_uri(); ?>/img/common/title_icon.png" alt="">
        </div>
        <p class="section-title__ja">診療科目</p>
        <p class="section-title__en">Treatment</p>
      </h2>
      <!-- <h3 class="top-treatment__text-h3">早期発見・早期治療が大事な脳の病気。</h3>
      <p class="top-treatment__text">
        頭の専門医として、脳卒中や認知症だけではなく、頭痛やめまい、しびれなどの<br>日常的な症状まで幅広く治療を行っております。<br>どんなに小さな悩みでもお気軽にご相談ください。
      </p> -->
      <?php the_field('top_treatment', 8); ?>
      <a href="<?php echo home_url("treatment"); ?>" class="top-treatment__btn btn">
        <p class="btn__text">もっと見る</p>
        <div class="top-treatment__arrow-wrapper--btn arrow-wrapper--btn">
          <div class="arrow"></div>
          <div class="arrow-rotate"></div>
        </div>
      </a>
    </div> <!-- wrapper -->
  </div> <!-- inner -->
</section>

<!-- contact -->
<section class="top-contact">
  <div class="top-contact__img sp-only u-mobile">
    <img src="<?php echo get_template_directory_uri(); ?>/img/top/top_contact.jpg" alt="">
  </div>
  <div class="top-contact__wrapper section-index-text-wrapper">
    <h2 class="top-contact-title section-title">
      <div class="section-title__img">
        <img src="<?php echo get_template_directory_uri(); ?>/img/common/title_icon.png" alt="">
      </div>
      <p class="section-title__ja">お問い合わせ</p>
      <p class="section-title__en">Contact</p>
    </h2>
    <!-- <p class="top-contact__text">
      当クリニックは地域の皆様の第一の相談相手を<br>目指しております。<br>何でもお気軽にお問合せください。
    </p> -->
    <?php the_field('top_contact', 8); ?>
    <a href="<?php echo home_url("contact"); ?>" class="top-contact__btn btn">
      <p class="btn__text">お問い合わせ</p>
      <div class="top-contact__arrow-wrapper--btn arrow-wrapper--btn">
        <div class="arrow"></div>
        <div class="arrow-rotate"></div>
      </div>
    </a>
  </div> <!-- wrapper -->
</section>
    
<!-- access -->
<section class="top-access">
  <div class="top-access__inner inner">
    <h2 class="top-access-title section-title">
      <div class="section-title__img">
        <img src="<?php echo get_template_directory_uri(); ?>/img/common/title_icon.png" alt="">
      </div>
      <p class="section-title__ja">アクセス</p>
      <p class="section-title__en">Access</p>
    </h2>
    <div class="top-access-map__area">
      <!-- <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3241.747975777087!2d139.74285797590022!3d35.658580472594636!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x60188bbd9009ec09%3A0x481a93f0d2a409dd!2z5p2x5Lqs44K_44Ov44O8!5e0!3m2!1sja!2sjp!4v1699194505118!5m2!1sja!2sjp" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe> -->
      <?php the_field('top_map', 8); ?>
    </div>
    <p class="top-access-map__message">
      病院の敷地内に6台の駐車スペースを<br class="u-mobile">ご用意しております。<br>※駐車場内での事故等のトラブルについては一切責任を負いかねます。あらかじめご了承ください。
    </p>
    <div class="top-access-schedule">
      <img src="<?php echo get_template_directory_uri(); ?>/img/common/schedule.jpg" alt="">
    </div>
  </div> <!-- inner -->
</section>
<?php get_footer(); ?>

