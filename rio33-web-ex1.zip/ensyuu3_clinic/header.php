<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <title><?php echo bloginfo('name'); ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="format-detection" content="telephone=no" />
  <meta name="description" content="<?php bloginfo('description'); ?>">
  <meta name="keywords" content="" />
  <meta name=“robots” content=“noindex”>
  <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
  <style>
    html{font-family:'Hiragino Kaku Gothic ProN', 'Noto Sans JP', sans-serif;}
  </style>
  <?php wp_enqueue_script('jquery'); ?>
  <?php wp_head(); ?> <!-- </head>の直前に入れる -->
</head>

<body class="home">
<div id="container">

<header>
	<div class="header__inner inner">
    <h1 class="header__logo">
      <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
        <img class="header__logo-img" src="<?php echo get_template_directory_uri(); ?>/img/common/header_logo.png" alt="ヘッダーロゴ">
      </a>
    </h1>
    <button class="header__hamburger hamburger js-hamburger">
      <span class="span"></span>
      <span class="span"></span>
      <span class="span"></span>
    </button>
    <nav class="header__nav header-nav js-drawer">
      <ul class="header-nav__items">
        <li class="header-nav__item">
          <a href="<?php echo home_url("about"); ?>">クリニックについて</a>
        </li>
        <li class="header-nav__item">
          <a href="<?php echo home_url("news"); ?>">お知らせ</a>
        </li>
        <li class="header-nav__item">
          <a href="<?php echo home_url("treatment"); ?>">診療案内</a>
        </li>
        <li class="header-nav__item">
          <a href="<?php echo home_url("contact"); ?>">お問い合わせ</a>
        </li>
      </ul>
    </nav>
  </div>
</header>



