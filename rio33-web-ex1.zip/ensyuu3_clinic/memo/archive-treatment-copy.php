<?php get_header(); ?>
<!-- カスタム投稿　プラグイン（Custom Post Type UI） -->

<!-- mv -->
<main>
  <div class="mv2 treatment__mv">
    <div class="mv2__title-wrapper">
      <h2 class="mv2__title">Treatment</h2>
      <p class="mv2__subtitle">診療科目</p>
    </div>
  </div> <!-- mv -->
</main>  

<!-- page-nav -->
<p class="page-nav">
  <a href="./index.html" class="page-nav__accent">HOME</a>
  <span class="page-nav__arrow">＞</span>
  診療科目
</p>

<div class="treatment__btn-wrapper">
  <a href="#category1" class="blue-btn treatment__btn">身体の痛み</a>
  <a href="#category2" class="blue-btn treatment__btn">身体機能の不調</a>
  <a href="#category3" class="blue-btn treatment__btn">健診</a>
</div>

<!-- ーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーー -->


<section class="category1__wrapper">
  <div class="treatment__inner">
  <!-- title -->
    <h2 class="category1-title section-title">
      <div class="section-title__img">
        <img src="<?php echo get_template_directory_uri(); ?>/img/common/title_icon.png" alt="">
      </div>
      <p class="section-title__ja">身体の痛み</p>
    </h2>
    <p class="section-text">
      ちょっとした痛みからやってくる病気も少なからず存在します。<br>少しでも異変を感じたら早期に受診しましょう。
    </p>



    <div class="eyecatch-wrapper">

      <?php
      // 1. 記事を取得するための条件指定
        $args = array(
          'post_type' => 'treatment',
          'posts_per_page' => 3,
          'order' => 'DESC',
          'tax_query' => array(
            array(
              'taxonomy' => 'treatment-category',
              'terms' => array('category1'),
              'field' => 'slug'
            ),
          ),
        );
      // 2. クエリの定義「WP_Query」
        $the_query = new WP_Query( $args );
      ?>
      <!-- 3. 取得内容をループさせ、取得内容を表示 -->
      <?php if ( $the_query->have_posts() ): while ( $the_query->have_posts() ): $the_query->the_post(); ?>

      <!-- ループさせる内容ここから -->
        <a href="<?php the_permalink(); ?>" class="eyecatch-content">
          <div class="eyecatch-content__img">
            <?php the_post_thumbnail('thumbnail'); ?>
          </div>
          <p class="eyecatch-content__name">
            <?php the_title(); ?>
          </p>
        </a>
      <!-- ループさせる内容ここまで -->

      <!-- 4. ループの終了と投稿データのリセット「wp_reset_postdata」 -->
      <?php endwhile; endif; wp_reset_postdata(); ?>

    </div>
  </div> <!-- inner -->
</section>
<!-- --------------------------------------------------------------------------------------------------------- -->




<!-- ーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーー -->

<a name="category1">
<section class="category1__wrapper"></a>
  <div class="treatment__inner">
  <!-- title -->
    <h2 class="category1-title section-title">
      <div class="section-title__img">
        <img src="<?php echo get_template_directory_uri(); ?>/img/common/title_icon.png" alt="">
      </div>
      <p class="section-title__ja">身体の痛み(htmlのまま)</p>
    </h2>
    <p class="section-text">
      ちょっとした痛みからやってくる病気も少なからず存在します。<br>少しでも異変を感じたら早期に受診しましょう。
    </p>
  <!-- eyecatch -->
    <div class="eyecatch-wrapper">
      <a href="./treatment _about.html" class="eyecatch-content">
        <div class="eyecatch-content__img">
          <img src="<?php echo get_template_directory_uri(); ?>/img/treatment/treatment_eyecatch_1.jpg" alt="">
        </div>
        <p class="eyecatch-content__name">
          １
        </p>
      </a>
      <a href="" class="eyecatch-content">
        <div class="eyecatch-content__img">
          <img src="<?php echo get_template_directory_uri(); ?>/img/treatment/treatment_eyecatch_2.jpg" alt="">
        </div>
        <p class="eyecatch-content__name">
          ２
        </p>
      </a>
      <a href="" class="eyecatch-content">
        <div class="eyecatch-content__img">
          <img src="<?php echo get_template_directory_uri(); ?>/img/treatment/treatment_eyecatch_3.jpg" alt="">
        </div>
        <p class="eyecatch-content__name">
          ３
        </p>
      </a>
    </div>
  </div> <!-- inner -->
</section>

    
<?php get_footer(); ?>



