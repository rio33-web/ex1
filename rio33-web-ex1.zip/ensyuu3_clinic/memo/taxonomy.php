<?php get_header(); ?>
<div id="contents">
<main>
<section>
<h2><?php single_cat_title(); ?></h2>
<div class="list-container">

<!-- メインクエリの書き方ここから -->
<?php if (have_posts() ) : 
  while (have_posts() ) :the_post();

  if(has_post_thumbnail()):
    $id=get_post_thumbnail_id();
    $img_src=wp_get_attachment_image_src($id)[0];
    //アイキャッチ画像のリンクを取得
  else:
    $img_src=get_template_directory_uri()."/images/1.jpg";
    //アイキャッチ画像が設定されていなかったときこちらの画像を表示
  endif;
?>
<!-- メインクエリの書き方ここまで -->


<div class="list">
	<div>
	<figure><img src="<?php echo $img_src; ?>" alt=""></figure>	
  <h4><?php the_title(); ?></h4>
	<p>
    <!-- <?php the_content(); ?> -->
    <?php echo wp_trim_words(get_the_content(), 200, '...'); ?>
  </p>
	</div>
	<p class="btn"><a href="<?php the_permalink(); ?>">詳細を見る</a></p>
  </div>

  <?php endwhile; ?>
  <?php wp_reset_postdata(); ?>
  <?php else : ?>
  <p><?php esc_html_e( '記事がありません' ); ?></p>
  <?php endif; ?>
</div>
<!--/.list-container-->
</section>
</main>
<?php get_footer(); ?>