<?php


function add_css_js() {
	//CSSの読み込みはここから
  // animateの読み込み
  //css/reset.cssを読み込み
	wp_enqueue_style('reset', get_theme_file_uri('/css/reset.css'));
  // swiperの読み込み
	wp_enqueue_style('swiper-css', get_theme_file_uri('/js/swiper/swiper.min.css'));
	//style.cssを読み込み
	wp_enqueue_style('style', get_theme_file_uri().'/css/style.css',
  [],
  date("YmdHis"),);

	//JavaScriptの読み込みはここから
  //デフォルトの jQuery は読み込まない
  wp_deregister_script('jquery');
  // jqueryの読み込み
	wp_enqueue_script('jquery','https://code.jquery.com/jquery-3.6.0.min.js', array(), '', true);
  // swiperの読み込み
	wp_enqueue_script('swiper-min-js', get_theme_file_uri('/js/swiper/swiper.min.js'), array(), '', true);
	wp_enqueue_script('swiper-js', get_theme_file_uri('/js/swiper.js'), array(), '', true);
	//js/script.jsを読み込み
	wp_enqueue_script('js', get_theme_file_uri('/js/script.js'), array(), '', true);
}
//関数名add_scripts()を表側で呼び出す
add_action('wp_enqueue_scripts', 'add_css_js');




// 消さない
?>

