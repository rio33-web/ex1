<?php get_header(); ?>

<!-- mv -->
<main>
  <div class="mv2 contact-form__mv">
    <div class="mv2__title-wrapper">
      <h2 class="mv2__title">Contact</h2>
      <p class="mv2__subtitle">お問い合わせ</p>
    </div>
  </div> <!-- mv -->
</main>  

<!-- page-nav -->
<p class="page-nav">
  <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="page-nav__accent">HOME</a>
  <span class="page-nav__arrow page-nav__accent">＞</span>
  <a href="<?php echo home_url("contact"); ?>" class="page-nav__accent">お問い合わせ</a>
  <span class="page-nav__arrow">＞</span>
  お問い合わせ完了
</p>

<!-- contact-form -->
<section class="contact-send">
  <div class="contact-send__inner">
    <h2 class="contact-send-title section-title">
      <div class="section-title__img">
        <img src="<?php echo get_template_directory_uri(); ?>/img/common/title_icon.png" alt="">
      </div>
      <p class="section-title__ja">送信完了</p>
    </h2>
    <p class="contact-send__text">
      この度はお問い合わせいただき、有難うございました。<br>
      3営業日以内にご返信させていただきますので、しばらくお待ちくださいませ。
    </p>
    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="contact-send__btn blue-btn">
      ホームに戻る
    </a>
  </div> <!-- inner -->
</section>
<?php get_footer(); ?>