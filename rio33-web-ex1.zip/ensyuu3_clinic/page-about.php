<?php get_header(); ?>

<!-- mv -->
<main>
  <div class="mv2 about__mv">
    <div class="mv2__title-wrapper">
      <h2 class="mv2__title">
        <?php
        $page_obj = get_page_by_path('about');
        $page = get_post( $page_obj );
        echo $page->post_name;
        ?>
      </h2>
      <p class="mv2__subtitle">
        <?php
        $page_obj = get_page_by_path('about');
        $page = get_post( $page_obj );
        echo $page->post_title;
        ?>
      </p>
    </div>
  </div> <!-- mv -->
</main>  

<!-- page-nav -->
<p class="page-nav">
  <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="page-nav__accent">HOME</a>
  <span class="page-nav__arrow">＞</span>
  <?php
    $page_obj = get_page_by_path('about');
    $page = get_post( $page_obj );
    echo $page->post_title;
  ?>
</p>

<!-- 院長紹介 -->
<section class="doctor">
  <div class="inner">
    <h3 class="doctor__title">院長紹介</h3>
    <div class="doctor__wrapper">
    <img src="<?php echo get_template_directory_uri(); ?>/img/about/about_head-doctor.jpg" alt="" class="doctor__img">
      <div class="doctor__massage-wrapper">
        <p class="doctor__massage">        
          <?php
          $page_obj = get_page_by_path('about');
          $page = get_post( $page_obj );
          echo $page->post_content;   //本文を表示
          ?>
        </p>
        <p class="doctor__hospital">渡邉脳神経外科クリニック院長</p>
        <img src="<?php echo get_template_directory_uri(); ?>/img/about/about_head-doctor_sign.png" alt="" class="doctor__sign">
      </div> <!-- message-wrapper -->
    </div> <!-- inner -->
  </div> <!-- wrapper -->
</section>

<!-- 院内紹介 -->
<section class="hospital">
  <div class="inner">
    <h3 class="hospital__title">院内紹介</h3>
    <p class="hospital__massage">
      <?php the_field('hospital_text'); ?>
      <!-- ご来院の皆さまがリラックスして診察を受けていただけるよう、木目を基調とした清潔感ある落ち着いた空間造りを目指しています。<br><br class="u-mobile">最新の装置を導入し、異常の早期発見、早期対応ができるように努めています。<br><br class="u-mobile">他の医療機関とも連携体制を構築し、患者様に適切な医療を提供いたします。 -->
    </p>
    <div class="hospital__img-wrapper">
      <div class="hospital__img">
        <img src="<?php the_field('hospital_img1'); ?>">
      </div>
      <div class="hospital__img">
        <img src="<?php the_field('hospital_img2'); ?>">
      </div>
      <div class="hospital__img">
        <img src="<?php the_field('hospital_img3'); ?>">
      </div>
      <div class="hospital__img">
        <img src="<?php the_field('hospital_img4'); ?>">
      </div>
      <div class="hospital__img">
        <img src="<?php the_field('hospital_img5'); ?>">
      </div>
      <div class="hospital__img">
        <img src="<?php the_field('hospital_img6'); ?>">
      </div>
    </div> <!-- img-wrapper -->
  </div> <!-- inner -->
</section>

<?php get_footer(); ?>