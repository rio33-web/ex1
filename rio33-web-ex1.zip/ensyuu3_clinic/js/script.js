jQuery(function ($) {

  // drawer----------------------------------------------------
  $('.js-hamburger').on('click', function(){

    $('.hamburger').toggleClass('hamburger2');
    $('.header-nav').toggleClass('header-nav2');
    $(".circle-bg").toggleClass('circle-bg2');
    $(".header").toggleClass('header2');

    // ドロワーメニューが開いている時の処理
    if ($(this).hasClass('open')) {
      $('.js-drawer').fadeOut();
      $(this).removeClass('open');
      $('html').removeClass('fixed');
    // ドロワーメニューが閉じている時の処理
    } else {
      $('.js-drawer').fadeIn();
      $(this).addClass('open');
      $('html').addClass('fixed');
    }
  });
  // drawerここまで-------------------------------------------------




});