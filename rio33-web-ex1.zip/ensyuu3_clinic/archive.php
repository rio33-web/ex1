<?php get_header(); ?>
<!-- wp管理画面から一覧ページ表示不可のため、リンクから行く -->
<!-- 投稿記事を10個くらい用意してから一覧ページを作成する（プラグイン Yoast Duplicate Post で複製楽早） -->

<!-- mv -->
<main>
  <div class="mv2 news__mv">
    <div class="mv2__title-wrapper">
      <h2 class="mv2__title">News</h2>
      <p class="mv2__subtitle">お知らせ</p>
    </div>
  </div> <!-- mv -->
</main>  

<!-- page-nav -->
<p class="page-nav">
  <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="page-nav__accent">HOME</a>
  <span class="page-nav__arrow">＞</span>
    お知らせ
  </p>

<section class="news-list">
  <div class="inner">
    <div class="news-list__pc-flex">
      <div class="news-list__items">
      
      <!-- // 処理を開始 -->
      <?php if(have_posts()): ?> <!-- 始まる -->
      <?php while(have_posts()): the_post(); ?> <!-- 繰り返す -->
      
        <!-- 投稿記事がある場合の処理内容 -->
        <a href="<?php the_permalink(); ?>" class="news-list__item news-list-item">
          <div class="news-list-item__left">

            <div class="category-wrapper">
              <?php if (has_term('','category')): ?>
                <div class="category-border">
                  <?php
                    $cats = get_the_terms($post->ID,'category');
                    foreach ( $cats as $cat ){
                      echo $cat->cat_name;
                      $cat_id = $cat->term_id;
                      $cat_color = 'category_'.$cat_id;
                      $text_color = get_field('color-pic',$cat_color);
                  ?>
                    <span class="category-text" 
                      style="color: <?php echo $text_color; ?>" 
                      style="border: 1px solid <?php echo $text_color; ?>">
                      <?php $cat = get_the_category(); $cat = $cat[0]; { echo $cat->cat_name; } ?>
                    </span>
                  <?php } ?>
                </div>
              <?php endif; ?>
              </span>
            </div>
            <p class="news-list-item__title">
              <?php the_title(); ?>
            </p>
            <div class="news-list-item__meta">
              <time class="date news-list-item__meta-date" datetime="2022-03-31">
                <?php echo get_the_date(); ?>
                <!-- デフォは２つ目以降が省略される、設定で表示スタイル変更可 -->
              </time>
            </div>
          </div> <!-- left -->
          <div class="news-list-item__right">
            <?php the_post_thumbnail('thumbnail'); ?>
          </div>    
        </a>
      <?php endwhile; ?>

      <div class="wp-pagenavi-wrapper">
        <?php if (function_exists('wp_pagenavi')) {
          wp_pagenavi(); } ?>
      </div>

      <?php else: ?>
      <!-- 投稿記事がない場合の処理内容 -->
      <?php endif; ?>
      <!-- 処理を終了       -->
        
      </div> <!-- items -->
      <?php get_sidebar(); ?>
    </div> <!-- pc-flex -->







    
  </div> <!-- inner -->
</section>
<?php get_footer(); ?>