<?php get_header(); ?>

<!-- mv -->
<main>
  <div class="mv2 news__mv">
    <div class="mv2__title-wrapper">
      <h2 class="mv2__title">News</h2>
      <p class="mv2__subtitle">お知らせ</p>
    </div>
  </div> <!-- mv -->
</main>  

<!-- page-nav -->
<p class="page-nav">
  <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="page-nav__accent">HOME</a>
  <span class="page-nav__arrow page-nav__accent">＞</span>
  <a href="<?php echo home_url("news"); ?>" class="page-nav__accent">お知らせ</a>
  <span class="page-nav__arrow">＞</span>
  営業時間について
</p>

<section class="news-about">
  <div class="news-about__pc-flex inner">
    <div class="news-about-item"> <!-- pc-left -->
    
      <!-- 処理を開始 -->
      <?php if(have_posts()): ?>
      <?php while(have_posts()): the_post(); ?>

        <div class="news-about-item__img">
          <?php the_post_thumbnail('thumbnail'); ?>
        </div>
        <div class="news-about-item__cat-and-meta"> <!-- pc-only -->
          <div class="category category-color2">
            <span class="category-text">
              <?php $cat = get_the_category(); $cat = $cat[0]; { echo $cat->cat_name; } ?>
            </span>
          </div>
            <time class="date news-about-item__meta-date" datetime="2022-03-31">
              <?php echo get_the_date(); ?>
            </time>
        </div>  <!-- pc-only -->
        <h4 class="news-about-item__title section-title--blue-wrapper">
          <span class="section-title--blue"></span>
          <p class="section-title--blue-text">
            <?php the_title(); ?>
          </p>
        </h4>
        <p class="news-about-item__text">
          <?php the_content(); ?>
        </p>
      
      <!-- 投稿記事がある場合の処理内容 -->
      <?php endwhile; ?>
      <?php else: ?>
      <!-- 投稿記事がない場合の処理内容 -->
      <?php endif; ?>
      <!-- 処理を終了    -->
  
      <div class="news-about-item__btmnav">
        <a href="" class="news-about-item__btmnav-prev">
          <img src="./img/common/arrow_icon_blue.svg" class="news-about-item__btmnav-prev__arrow" alt="">
          <p>前の記事</p>
        </a>
        <a href="<?php echo home_url("news"); ?>" class="news-about-item__btmnav-pcbtn blue-btn u-desktop">
          お知らせ一覧へ
        </a>
        <a href="" class="news-about-item__btmnav-next">
          <p>後の記事</p>
          <img src="./img/common/arrow_icon_blue.svg" class="news-about-item__btmnav-next__arrow" alt="">
        </a>
      </div>
      <a href="<?php echo home_url("news"); ?>" class="news-about-item__btmnav-spbtn blue-btn">
        お知らせ一覧へ
      </a>
    </div> <!-- pc-left -->
    <?php get_sidebar(); ?>
  </div> <!-- pc-flex -->
  

  
</section>
<?php get_footer(); ?>



