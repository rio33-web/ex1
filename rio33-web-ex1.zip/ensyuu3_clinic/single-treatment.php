<?php get_header(); ?>

<!-- mv -->
<main>
  <div class="mv2 treatment__mv">
    <div class="mv2__title-wrapper">
      <h2 class="mv2__title">Treatment</h2>
      <p class="mv2__subtitle">診療科目</p>
    </div>
  </div> <!-- mv -->
</main>  

<!-- page-nav -->
<p class="page-nav">
  <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="page-nav__accent">HOME</a>
  <span class="page-nav__arrow page-nav__accent">＞</span>
  <a href="<?php echo home_url("treatment"); ?>" class="page-nav__accent">診療科目</a>
  <span class="page-nav__arrow">＞</span>
  頭痛
</p>

<section class="treatment-about">
  <div class="treatment-about__inner">
    <div class="treatment-about__img">
      <?php the_post_thumbnail('thumbnail'); ?>
    </div>
    <h4 class="treatment-about__title-wrapper section-title--blue-wrapper">
      <span class="section-title--blue"></span>
      <p class="section-title--blue-text">
        <?php the_title(); ?>
      </p>
    </h4>
    <p class="treatment-about__text">
      <?php the_content(); ?>
    </p>
    <a href="<?php echo home_url("treatment"); ?>" class="blue-btn treatment-about__btn">診療科目一覧へ</a>
  </div> <!-- inner -->
</section>
    
<?php get_footer(); ?>