<?php get_header(); ?>

<!-- mv -->
<main>
  <div class="mv2 contact-form__mv">
    <div class="mv2__title-wrapper">
      <h2 class="mv2__title">Contact</h2>
      <p class="mv2__subtitle">お問い合わせ</p>
    </div>
  </div> <!-- mv -->
</main>  

<!-- page-nav -->
<p class="page-nav">
  <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="page-nav__accent">HOME</a>
  <span class="page-nav__arrow">＞</span>
  お問い合わせ
</p>

<section class="contact-form">
  <div class="contact-form__inner">
    <h2 class="contact-form-title section-title">
      <div class="section-title__img">
        <img src="<?php echo get_template_directory_uri(); ?>/img/common/title_icon.png" alt="">
      </div>
      <p class="section-title__ja">お問い合わせフォーム</p>
    </h2>
    <p class="contact-form__top-text">
      ご質問、ご要望、ご相談は下記フォームを<br class="u-mobile">ご利用ください。<br>
      ※体調に不安がある方は、直接医師の診察を<br class="u-mobile">お勧めします。
    </p>
    <div class="contact-form__blue-wrapper">
      <?php echo do_shortcode( '[contact-form-7 id="44d9834" title="お問い合わせフォーム"]' ); ?>
    </div>
  </div> 
</section>
<?php get_footer(); ?>