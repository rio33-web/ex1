<div class="news__nav">
  <div class="category-nav">
    <h4 class="category-nav__title">カテゴリー</h4>
    <div class="news__line line"></div>
    <?php
      $categories = get_categories();
      foreach($categories as $category) {
      echo '<a class="category-nav__item" href="'.get_category_link($category->term_id).'">'.$category->name.'</a>';
      }
    ?>
  </div>
  <div class="archive-nav">
    <h4 class="archive-nav__title">月別アーカイブ</h4>
    <div class="news__line line"></div>
    <?php wp_get_archives( 'type=monthly&limit=4' ); ?>
  </div>
</div> <!-- nav -->
